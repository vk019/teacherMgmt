import React from 'react'



export default function Logout() {
  return (
    <>
 <h5>You have logged out ...</h5>
    </>
  )
}