import React from 'react'
import dp from './dp.png'

export default function Profile() {
  return (
    
    <>
    
    <div className="card ">
        <form method="">
            <div className="row">
            <div className="col-md-4">
                <img src={dp} alt="profilepic" />
                </div>
                <div className="col-md-6">
                <div className="card-title">
                <h5>Test Teacher</h5>
                <h6>Teacher</h6>
                <ul className="nav nav-tabs" role="tablist">
                <li className="nav-item">
                <a className="nav-link active" id="home-tab" data-toggle="tab" role="tab" href="#home">About</a>
                </li>
                <li className="nav-item">
                <a className="nav-link active" id="profile-tab" data-toggle="tab" role="tab" href="#profile">Timeline</a>
                </li>
                </ul>
                </div>
                </div>
                <div className="col-md-2">
                    <input type="submit" className="profile-edit-btn" name="btnAddMore" value="Edit Profile"/>
                </div>
            </div>
        </form>
    </div>
    
    </>
  )
}
