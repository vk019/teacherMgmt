import React from 'react';
import { BrowserRouter as Router,Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import AddTeacher from './components/AddTeacher';
import TeacherList from './components/TeacherList';

function App() {
  return (
    <>
    <Router>
      <div>
        <Header/>
        <div className="main-content">
          <Routes>
            <Route  exact path="/AddTeacher" element={<AddTeacher/>} >
            </Route>
          </Routes>
            
            <Routes>
              <Route  exact path="/TeacherList" element={<TeacherList/>}>
              </Route>
              </Routes>
        </div>
      </div>
    </Router>
    </>
  );
};

export default App;