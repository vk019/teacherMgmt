import React from 'react';

const TeacherList = () => {
  return <h2>List of Teachers</h2>;
};

export default TeacherList;