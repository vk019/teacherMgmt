import React from 'react'

function Teacher() {
  return (
    <>
   
    <h1>Teacher</h1>
      
    </>
  )
}

export default Teacher;
