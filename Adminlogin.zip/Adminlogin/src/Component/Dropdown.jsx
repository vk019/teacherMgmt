import React, {useState} from 'react'
import {Link} from "react-router-dom"
import "../css/Sdropdown.css"


function Dropdown() {
  const[dropdown, setDropdown]= useState(false);
  return (
    <>
    <ul className={dropdown ? "teacher-submenu clicked" : "teacher-submenu"} onClick={()=>setDropdown(!dropdown)}>
        <li>
            <Link className="submenu-item" to="/login" >Teacher Status</Link>
        </li>
        <li>
            <Link className="submenu-item" to="/schoolLogin">Manage Teacher</Link>
        </li>
        <li >
            <Link className="submenu-item" to="/adminLogin">Add Teacher</Link>
        </li>
    </ul>
    </>
  )
}

export default Dropdown
