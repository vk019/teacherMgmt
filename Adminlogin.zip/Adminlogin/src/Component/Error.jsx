import React from 'react'

function Error() {
  return (
    <>
      <h1>Error 404 not found</h1>
    </>
  )
}

export default Error
