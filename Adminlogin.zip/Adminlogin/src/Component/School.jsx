import React from 'react'

function School() {
  return (
    <>
      <h1>School page</h1>
    </>
  )
}

export default School
