import React from 'react'

function Calendar() {
  return (
    <>
      <h1>Calendar Page</h1>
    </>
  )
}

export default Calendar
