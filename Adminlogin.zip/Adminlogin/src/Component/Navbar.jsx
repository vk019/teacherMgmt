import React, {useState} from 'react'
import {NavLink} from 'react-router-dom';
import Dropdown from './Dropdown';
import Sdropdown from './Sdropdown';
import '../css/navStyle.css'

function Navbar() {
  const[dropdown, setDropdown]= useState(false);
  const[sdropdown, setSdropdown]= useState(false);
  
  let activeStyle = {
    textDecoration: "none",
    color:"orange"
  };
  return (
    <>
    <header>
        <div className="lcontainer lcontainer-flex ">
          
          
          <nav className="navbar">
            <div className="List">

              <NavLink to="/" className="listItem"  style={({ isActive }) =>
              isActive ? activeStyle : undefined}>Home</NavLink>


              <NavLink to="/Calendar" className="listItem" id='cal' style={({ isActive }) =>
              isActive ? activeStyle : undefined } >Calendar</NavLink>

              <NavLink to="/Teacher" className="listItem" id='tea' style={({ isActive }) =>
              isActive ? activeStyle : undefined } onClick={()=> setDropdown(!dropdown)}>Teacher</NavLink>
              {dropdown && <Dropdown/>}

              <NavLink to="/School" className="listItem" id='sch'style={({ isActive }) =>
              isActive ? activeStyle : undefined } onClick={()=> setSdropdown(!sdropdown)}>School</NavLink>
              {sdropdown && <Sdropdown/>}
              
              <NavLink to="/Gallery" className="listItem" id='gall' style={({ isActive }) =>
              isActive ? activeStyle : undefined }>Gallery</NavLink>
            </div>
          </nav>

          <div className="login">
          <button className="btn" >Logout</button>
          
          </div>



        </div>
      </header>
      
      
    </>
  )
}

export default Navbar