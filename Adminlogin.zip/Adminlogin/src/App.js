import React from 'react'
import {Routes, Route} from 'react-router-dom'
import Home from './Component/Home'
import Teacher from './Component/Teacher'
import Calendar from './Component/Calendar'
import School from './Component/School'
import Gallery from './Component/Gallery'
import Navbar from './Component/Navbar'
import Footer from './Component/Footer'
import HeadFlex from './Component/HeadFlex'
import { useState } from 'react'




function App() {
  return (
    <>
      <HeadFlex/>
      <Navbar/>
      <Routes>
        <Route exact path='/' element={<Home/>}/>
        <Route path='/Calendar' element={<Calendar/>}/>
        <Route path='/Teacher' element={<Teacher/>}/>
        <Route path='/School' element={<School/>} />
        <Route path='/Gallery' element={<Gallery/>} />
      </Routes>
      
      {/*<Footer/>*/}
    </>
  )
}

export default App
