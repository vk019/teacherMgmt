import React from 'react'
import SDashboard from './SDashboard/index'

function School() {
  return (
    <>
      <SDashboard/>
    </>
  )
}

export default School
