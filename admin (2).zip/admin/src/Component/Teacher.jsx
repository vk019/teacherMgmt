import React from 'react'
import Dashboard from './Dashboard/index'


function Teacher() {
  return (
    <>
   
    <Dashboard/>
      
    </>
  )
}

export default Teacher;
