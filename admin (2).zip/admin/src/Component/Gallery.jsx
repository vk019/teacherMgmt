import React from 'react'

function Gallery() {
  return (
    <>
      <h1>Gallery Page</h1>
    </>
  )
}

export default Gallery
