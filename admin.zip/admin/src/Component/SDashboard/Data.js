const SchoolsData = [
    {
      id: 1,
      SchoolName: 'Susan',
      budget : '4000000',
      email: 'susan@example.com',
      income : '95000',
      date: '2019-04-11'
    },
    {
      id: 2,
      SchoolName: 'Adrienne',
      budget : '4000000',
      email: 'adrienne@example.com',
      income : '80000',
      date: '2019-04-17'
    },
    {
      id: 3,
      SchoolName: 'Rolf',
      budget : '4000000',
      email: 'rolf@example.com',
      income : '79000',
      date: '2019-05-01'
    },
    {
      id: 4,
      SchoolName: 'Kent',
      budget : '4000000',
      email: 'kent@example.com',
      income : '56000',
      date: '2019-05-03'
    },
    {
      id: 5,
      SchoolName: 'Arsenio',
      budget : '4000000',
      email: 'arsenio@example.com',
      income : '65000',
      date: '2019-06-13'
    },
    {
      id: 6,
      SchoolName: 'Laurena',
      budget : '4000000',
      email: 'laurena@example.com',
      income : '120000',
      date: '2019-07-30'
    },
    {
      id: 7,
      SchoolName: 'George',
      budget : '4000000',
      email: 'george@example.com',
      income : '90000',
      date: '2019-08-15'
    },
    {
      id: 8,
      SchoolName: 'Jesica',
      budget : '4000000',
      email: 'jesica@example.com',
      income : '60000',
      date: '2019-10-10'
    },
    {
      id: 9,
      SchoolName: 'Matthew',
      budget : '4000000',
      email: 'matthew@example.com',
      income : '71000',
      date: '2019-10-15'
    },
    {
      id: 10,
      SchoolName: 'Lyndsey',
      budget : '4000000',
      email: 'lyndsey@example.com',
      income : '110000',
      date: '2020-01-15'
    }
  ];
  
  export { SchoolsData };