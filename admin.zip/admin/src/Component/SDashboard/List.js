import React from 'react'

function List({Schools, handleEdit, handleDelete }) {

    const formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: null
    });

    return (
        <div className='contain-table'>
            <table className='striped-table'>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>School Name</th>
                        <th>Email</th>
                        <th>Budget</th>
                        <th>Income</th>
                        <th>Date</th>
                        <th colSpan={2} className="text-center">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {Schools.length > 0 ? (
                        Schools.map((School, i) => (
                            <tr key={School.id}>
                                <td>{i + 1}</td>
                                <td>{School.SchoolName}</td>
                                <td>{School.email}</td>
                                
                                <td>{formatter.format(School.budget)}</td>
                             
                                <td>{formatter.format(School.income)}</td>
                                <td>{School.date} </td>
                                <td className="text-right">
                                    <button
                                        onClick={() => handleEdit(School.id)}
                                        className="button muted-button"
                                    >
                                        Edit
                                    </button>
                                </td>
                                <td className="text-left">
                                    <button
                                        onClick={() => handleDelete(School.id)}
                                        className="button muted-button"
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan={7}>No Schools</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    )
}

export default List