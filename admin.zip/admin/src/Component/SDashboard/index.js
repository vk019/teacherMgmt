import React, { useState } from 'react'
import Swal from 'sweetalert2';

import Header from './Header';
import List from './List';
import Add from './Add';
import Edit from './Edit';

import { SchoolsData } from './Data';

function SDashboard() {

    const [Schools, setSchools] = useState(SchoolsData);
    const [selectedSchool, setSelectedSchool] = useState(null);
    const [isAdding, setIsAdding] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    const handleEdit = (id) => {
        const [School] = Schools.filter(School => School.id === id);

        setSelectedSchool(School);
        setIsEditing(true);
    }

    const handleDelete = (id) => {
        Swal.fire({
            icon: 'warning',
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
        }).then(result => {
            if (result.value) {
                const [School] = Schools.filter(School => School.id === id);

                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: `${School.SchoolName} 's data has been deleted.`,
                    showConfirmButton: false,
                    timer: 1500,
                });

                setSchools(Schools.filter(School => School.id !== id));
            }
        });
    }


    return (
        <div className='container'>
            {/* List */}
            {!isAdding && !isEditing && (
                <>
                    <Header
                        setIsAdding={setIsAdding}
                    />
                    <List
                        Schools={Schools}
                        handleEdit={handleEdit}
                        handleDelete={handleDelete}
                    />
                </>
            )}
            {/* Add */}
            {isAdding && (
                <Add
                    Schools={Schools}
                    setSchools={setSchools}
                    setIsAdding={setIsAdding}
                />
            )}
            {/* Edit */}
            {isEditing && (
                <Edit
                    Schools={Schools}
                    selectedSchool={selectedSchool}
                    setSchools={setSchools}
                    setIsEditing={setIsEditing}
                />
            )}
        </div>
    )
}

export default SDashboard;