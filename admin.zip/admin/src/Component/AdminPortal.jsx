import React from 'react'

function AdminPortal() {
  return (
    <div>
      
    </div>
  )
}

export default AdminPortal
